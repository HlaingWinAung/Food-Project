<?php include("header.php");
        include("nav.php");?>

    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search text-center">
        <div class="container">
            
            <form action="" method="post">
                <input type="search" name="search" placeholder="Search for Food.." required>
                <input type="submit" name="submit" value="Search" class="btn btn-primary">
            </form>

        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->



    <!-- fOOD MEnu Section Starts Here -->
    <h2 class="text-center">Food Menu</h2>
            <div class="container"  >
            <?php
					 error_reporting(1);
					 include("connection.php");
						$sel=mysql_query("SELECT * FROM item ");
						echo"<form method='post'><table  class='col'><tr>";
   $n=0;
    while($arr=mysql_fetch_array($sel))
   {
   $i=$arr['img'];
   
    if($n%3==0)
	{
	echo "<tr>";
	}
   echo "
   <td class='w-auto h-auto m-auto p-auto text-center'><img src='admin/image/$i'  class=' w-50  rounded rounded-3 ms-5  '><br/>
 
 <b>Product Name:  ".$arr['prod_no'].
   "<br><b>Price:</b>&nbsp;".$arr['price'].
  "<br><a href='login.php?img=$i' class='btn btn-danger'><i class='fas fa-shopping-cart'></i> Order Now</a>
 <br><br>
   </td>";
  
  $n++;

   }
   	  echo "</tr></table>
       </form>";
	?>	
       
       
  </div>
  </form>  
</div>
        
      
    
  


    <!-- fOOD Menu Section Ends Here -->

   

<?php include('footer.php'); ?>