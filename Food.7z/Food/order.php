<?php
error_reporting(1);
session_start();
$i=$_REQUEST['img'];
$_SESSION['sid']=$_POST['id'];
include("connection.php");
$i=$_REQUEST['img'];
if($_POST['ord'])
{ 
$prodno=$_POST['prodno'];
$price=$_POST['price'];
$name=$_POST['nam'];
$phone=$_POST['pho'];
$add=$_POST['add'];
$ordno=ord.rand(100,500);
if(mysql_query("INSERT INTO orders(product_no,price,name,phone,address,order_no) values('$prodno','$price','$name','$phone','$add','$ordno')"))
{
//echo "<script>location.href='ordersent.php?prod'</script>";
header("location:ordersent.php?order_no=$ordno");  }
else {$error= "user already exists";}}

?>


<?php include ("header.php") ;
include ("nav.php"); ?>


        
        
<section class="food-search">
<div class="container">
        <h1 class="text-center text-light">Order form</h1>
        <h2 class="text-center text-light">Fill this form to confirm your order</h2><br>
        <?php
			include("connection.php");
			$sel=mysql_query("SELECT * FROM item  WHERE img='$i' ");
			$mat=mysql_fetch_array($sel);
			
			
?>
           <form action="#" method="post" class="order text-white">
                
                
                <fieldset>
                   
                    <div class="order-label">Product Name</div>
                    <input type="text" name="prodno" placeholder="" class="input-responsive" required value="<?php echo $mat['prod_no'];?>">
                    <div class="order-label">Price</div>
                    <input type="text" name="price" placeholder="" class="input-responsive" required value="<?php echo $mat['price'];?>"  >
                    <div class="order-label">Name</div>
                    <input type="text" name="nam" class="input-responsive" required>
                    <div class="order-label">Phone</div>
                    <input type="text" name="pho" placeholder="09*********" class="input-responsive" required>
                    <div class="order-label">Address</div>
                    <textarea type="text" name="add" placeholder="" class="input-responsive" required></textarea>
                   
                    
                    <input type="submit" name="ord" value="Sent Order" class="btn btn-danger">
                    <input type="submit" name="Cancel" value="Cancel"  class="btn btn-danger" />
			
                </fieldset>

            </form>
</div>
        </div>
    </section>
            
       
   

    <?php include ("footer.php") ;  ?>
