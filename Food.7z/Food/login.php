<?php
session_start();
error_reporting(1);
$i=$_REQUEST['img'];
include("connection.php");

if(isset($_POST['log']))
{ if($_POST['id']=="" || $_POST['pwd']=="")
{ $err="fill your id and password first"; }

else 
{$d=mysql_query("SELECT * FROM register WHERE email='{$_POST['id']}' ");
$row=mysql_fetch_object($d);
$fid=$row->email;
$fpass=$row->password; 

if($fid==$_POST['id'] && $fpass==$_POST['pwd'])
{$_SESSION['sid']=$_POST['id'];
//echo"<script>location:href='order.php?img=$i'</script>";
header("location:order.php?img=$i"); 
}

else {$err=" Your Password Is Not"; }}
}
?>

<?php include ("header.php");
        include ("nav.php");?>
   
                <div class="card">
<div class="card-body">
	<h1 class="card-title text-center mb-4 mt-1">User Login</h1>
	<hr>
	<p class="text-success text-center">Some message goes here</p>
	<form align="center" method="post" name="contact" >
	<div class="form-group form-inline">
	</div> <!-- form-group// -->
	<div class="form-group">
     <i class='fas fa-user-circle form-inline'> <input type="email" placeholder="input your email" name="id" class="form-control"></i>  <br> <br>
    
     <i class='fas fa-unlock-alt form-inline'>  <input type="password" placeholder="input your password" name="pwd"  class="form-control"></i><br><br>
	<button type="submit" class="btn btn-primary  form-inline" name="log"> Login  </button>
	</div> <!-- form-group// -->
	<p class="text-center"><a href="#" class="btn">Forgot password?</a></p>
	</form>
    <h2 class="alert text-center text-danger"><?php echo $err; ?></h2>
</div>
</div> 
				
             	
   
   
   
   
   
 
   <?php     include ("footer.php"); ?>
  