<?php
session_start();
if($_SESSION['sid']=="")
{
header('location:login.php');
}
else{
 ?>

<?php include("nav.php"); ?>

        <div class="container-fluid col-md-8 cold-lg-12 col-sm-6 ">
             <?php
					 error_reporting(1);
					 include("connection.php");
						$sel=mysql_query("SELECT * FROM item ");
						echo " <form method='post' class='form-inline'>  <table class='table table-hover'> 
 
    <tr class='table table-info '>
      <td scope='col'>Image:</td>
      <td scope='col'>Product Name:</td>
      <td scope='col'>Price:</td>
    </tr>" ;  
   $n=0;
    while($arr=mysql_fetch_array($sel))
   {
   $i=$arr['img'];
   
    if($n%1==0)
	{
	echo "<tr><tr>
	      ";
	}
   echo 
   "<td><img src='image/$i' height='150' width='150' class='rounded  d-block'></td>
 <br>
 <td>".$arr['prod_no'].
   "</td><td>".$arr['price'].
  "
   </td>";
  
  $n++;

   }
   	  echo "</tr></table>
       </form>";
	?>	

</div>
       <?php include ("footer.php"); ?>
   <?php }  ?>
  