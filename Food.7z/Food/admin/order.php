<?php
session_start();
if($_SESSION['sid']=="")
{
header('location:login.php');
}
else{
 ?>
<?php include("nav.php"); ?>

<div class="container fluid">
<div class="row">
<div class="col-lg">
        <h1 class='text-center text-dark'>View Order Form</h1>
        <table class="table table-responsive-lg table-responsive-sm">
  <thead class="thead-dark inline-block">
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Product No:</th>
      <th scope="col">Price:</th>
      <th scope="col">Name:</th>
      <th scope="col">Phone:</th>
      <th scope="col">Address:</th>
      <th scope="col">Order No:</th>
    </tr>
  </thead>
  <tbody>
  <?php
					 error_reporting(1);
					 include("connection.php");
						$sel=mysql_query("SELECT * FROM orders ");
						while($row=mysql_fetch_array($sel))
							{		
						$id=$row['ord_id'];					
						$prodno=$row['product_no'];
						$price=$row['price'];
						$name=$row['name'];
						$phone=$row['phone'];
						$address=$row['address'];
						$ordno=$row['order_no'];
		?>
      <th scope="row">
      <tr>
                        <td><?php echo $id; ?></td>           
						<td><?php echo $prodno; ?></td>
						<td><?php echo $price; ?></td>
						<td><?php echo $name; ?></td>
						<td><?php echo $phone; ?></td>
						<td><?php echo $address; ?></td>
						<td><?php echo $ordno; ?></td>
      </th>
      </tr>
  </tbody>
  <?php				  
	}	
    ?>
</table>

</div>
</div>
</div>
<?php include("footer.php"); ?>
 <?php } ?>


