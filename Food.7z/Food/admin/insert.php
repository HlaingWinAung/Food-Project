<?php
session_start();
if($_SESSION['sid']=="")
{
header('location:login.php');
}
else{
 ?>

<?php
error_reporting(1);
include("connection.php");
$img=$_FILES['img']['name'];
$prono=$_POST['t1'];
$price=$_POST['t2'];
if($_POST['sub'])
{$qry="INSERT INTO item(img,prod_no,price)VALUES('$img','$prono','$price')";
$result=mysql_query($qry) or die ("save items query fail.");
if($result)			
	   {mkdir("image/$i");
			move_uploaded_file($_FILES['img']['tmp_name'],"image/$i".$_FILES['img']['name']);	
  // move_uploaded_file($_FILES['file']['tmp_name'],"itempics/$itemno.jpg");
		
	    $err="<font size='+2'>Item Inserted Successfully😊</font>";
	
		}
	else
	 {
	   echo "item is not inserted";
	   }
	}  
	mysql_close($con);
?>
<?php include("nav.php"); ?>

        <div class="col-md-8 col-lg-8 col-sm-3">
        <form  name="testform" method="post" enctype="multipart/form-data" >
                            <table class="table">
                                <thead align="center">
                                    <tr>
                                    <td><h1>Insert Products</h1></td>
                                    <br>
                                    </tr>
                                  
                                </thead>
                                <tbody>
                                    <tr>
                                  
                                      <td class="text-danger "><h4>Image  :</h4></td>  
                                      <td><input type="file" name="img" ></td>      
                                   
                                    </tr>
                                    <tr>
                                    <td class="text-danger "><h4>Product  Name  :</h4></td>  
                                   <td> <input type="text" name="t1"></td>
                                    </tr>
                                    <tr>
                                    <td class="text-danger "><h4>Price :</h4></td>  
                                   <td> <input type="text" name="t2"></td>
                                    </tr>
                                    <tr>
                                    <td colspan="2" align="center"> <input name="sub" type="submit" value="Submit" class="btn btn-success"></td>
                                    </tr>
                                </tbody>
                            </table>
                            </form>
                            <h2><?php echo $err;?></h2>
                     
  
        </div>
        <?php include ("footer.php") ;  ?>
  <?php }  ?> 