<?php
session_start();
if($_SESSION['sid']=="")
{
header('location:login.php');
}
else{
 ?>
<?php include("nav.php"); ?>
<div class="container fluid">
<div scope="row">
<div class="col-lg-12">
        <h1 class='text-center text-dark'>View Feedback Message</h1>
        <table class="table">
  <thead class="thead-dark inline-block">
    <tr>
      <th scope="col">ID:</th>
      <th scope="col">Name:</th>
      <th scope="col">Email:</th>
      <th scope="col">Phone:</th>
      <th scope="col">Message:</th>
    </tr>
  </thead>
  <tbody>
  <?php
					 error_reporting(1);
					 include("connection.php");
                     $sel=mysql_query("SELECT * FROM content ");
                     while($row=mysql_fetch_array($sel))
                         {		
                                 $id=$row['con_id'];					
                                 $name=$row['name'];
                                 $email=$row['email'];
                                 $phone=$row['phone'];
                                 $mesg=$row['mesg'];
		?>
   
      <tr>
                        <td><?php echo $id; ?></td>
						<td ><?php echo $name; ?></td>
						<td><?php echo $email; ?></td>
						<td><?php echo $phone; ?></td>
						<td><?php echo $mesg; ?></td>
    
      </tr>
    
  </tbody>
  <?php				  
	}	
    ?>
</table>

</div>
</div>
</div>

<?php include("footer.php"); ?>
 <?php } ?>