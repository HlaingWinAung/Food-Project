<?php include ("header.php") ;
include ("nav.php"); ?>

    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search">
        <div class="container">
            
            <h2 class="text-center text-white">Fill this form to confirm your detail.</h2>
  <?php
            error_reporting(1);
            include("connection.php");
            if($_POST['sub'])
            { 
            $name=$_POST['t1'];
            $email=$_POST['t2'];
            $password=$_POST['t3'];
            $phone=$_POST['t4'];
            $city=$_POST['t5'];
            $town=$_POST['t6'];
            if(mysql_query("INSERT INTO register (name,email,password,phone,city,township) values('$name','$email','$password','$phone','$city','$town')"))
            {
                header("location:reg_success.php?name=$name & email=$email");}
            else {$error= "user already exists";}}

?>
            <form action="#" method="post" class="order text-white">
                
                
                <fieldset>
                   
                    <div class="order-label">Full Name</div>
                    <input type="text" name="t1" placeholder="" class="input-responsive" required>
                    <div class="order-label">Email</div>
                    <input type="email" name="t2" placeholder="@gmail.com" class="input-responsive" required>
                    <div class="order-label">Password</div>
                    <input type="password" name="t3" placeholder="" class="input-responsive" required>
                    <div class="order-label">Phone</div>
                    <input type="text" name="t4" placeholder="09*********" class="input-responsive" required>
                    <div class="order-label">City</div>
                    <input type="text" name="t5" placeholder="" class="input-responsive" required>
                    <div class="order-label">Township</div>
                    <input type="text" name="t6" placeholder="" class="input-responsive" required>
                    
                    <input type="submit" name="sub" value="Register" class="btn btn-danger">
                    <input type="submit" name="Cancel" value="Cancel"  class="btn btn-danger" />
				<label> <?php echo "<font color='red'> $error </font>"; ?></label>
                </fieldset>

            </form>

        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->

 

    <?php include ("footer.php") ;  ?>
