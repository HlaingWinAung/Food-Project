<?php
	error_reporting(1);
	
	include("connection.php");
	
	if($_REQUEST['log']=='out')
	{
		session_destroy();
		header("location:index.php");
	}
?>
<?php include ("header.php") ;
     include ("nav.php"); ?>
    
    <div class="container text-dark">
<h2 class="text-center">Welcome!! <?php echo "<span class='alert alert-warning text-center'>".$_REQUEST['name']."</span>"; ?> </h2>
	 
     <br>
     <p>You have created your account successfully!!!</p>
     
     <p>Thank you for registration.</p>
     <button class="btn btn-danger"><a href="?log=out" class="text-light">Go back</a></button>
 
     </div>



<?php include ("footer.php") ;  ?>
