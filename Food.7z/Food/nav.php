 <!-- Navbar Section Starts Here -->
 <section class="navbar-expand">
        <div class="container">
            <div class="logo">
                <a href="index.php" title="Logo">
                    <img src="images/logo.png" alt="Restaurant Logo" class="img-responsive">
                </a>
            </div>

            <div class="menu text-right">
                <ul>
                    <li>
                        <a href="index.php" class="text-danger"> <i class="fas fa-home"></i> Home</a>
                    </li>
                    <li>
                        <a href="product.php" class="text-danger"><i class="fas fa-shopping-cart"> Product</i></a>
                    </li>
                    <li>
                        <a href="register.php" class="text-danger"><i class="fas fa-user-plus">Register</i></a>
                    </li>
                    <li>
                        <a href="contact.php" class="text-danger"><i class="fas fa-phone-square-alt">Contact</i></a>
                    </li>
                </ul>
            </div>

            <div class="clearfix"></div>
        </div>
    </section>
    <!-- Navbar Section Ends Here -->