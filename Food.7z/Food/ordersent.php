<?php
	error_reporting(1);
	
	include("connection.php");
	
	if($_REQUEST['log']=='out')
	{
		session_destroy();
		header("location:index.php");
    }
?>
<?php include ("header.php");
        include ("nav.php");?>


<div class="container text-center text-dark">
	
<h2><span>Thank you for shopping with us 😊</span></h2>
          <p class="alert alert-success"><i><strong>Order Sent Successfully!</strong></i> ✅</p>
		  <p>Your order no. is <?php echo "<h2>".$_REQUEST['order_no']."</h2>";?></p>
		  <p>Thank you. Please come again.</p>
		  <br>
		<button class="btn btn-danger"><a href="logout.php" class="text-light">Log out</a></button> 
            
          </div>

<br><br><hr>

<?php include ("footer.php"); ?>