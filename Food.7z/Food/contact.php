  <?php
error_reporting(1);
include("connection.php");
if($_POST['sub'])
{ 
$name=$_POST['t1'];
$email=$_POST['t2'];
$phone=$_POST['t3'];
$mesg=$_POST['t4'];
if(mysql_query("INSERT INTO content(name,email,phone,mesg) values('$name','$email','$phone','$mesg')"))
{$er="<font color='red' size='+2'> Message sent successfully</font>"; }
}

?>
<?php include ("header.php");
        include ("nav.php");?>
   

   <div class="container text-left mr-6">
<h2>Contact Information</h2><hr>
            <div id="contact_form" class="col-md-8 col-lg-6 bg-light">
                <h3>Send a message</h3><br>
                <form method="post" name="contact" action="#" class="form-col">
                    <div class="col">
                        <label for="phone">Name:</label>
                        <input type="text" id="t1" name="t1" class="required input_field" />
                    </div>
                    <div class="col no_margin_right">
                        <label for="email">Email:</label>
                        <input type="email" id="t2" name="t2" class="validate-email required input_field" />
                    </div>
                    <div class="clear h10"></div>
                     <div class="col no_margin_right">
                        <label for="phone">Phone:</label>
                        <input type="text" id="t3" name="t3" class="required input_field" />
                    </div>
                    <div class="clear"></div>
                    <label for="text">Message:</label> <textarea id="t4" name="t4" rows="0" cols="0" class="required"></textarea><br>
                     <input type="submit" name="sub"  id="sub" value="Send" class="btn btn-danger" />
                </form>
				<h2><?php echo $er;?></h2>
            </div> 
               
			</div>
            

                </div>
            </div>

   <?php  include ("footer.php"); ?>